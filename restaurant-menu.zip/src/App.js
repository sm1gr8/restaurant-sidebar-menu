import React from 'react'
import Restaurant from './component/Restaurant'

const App = () => {
  return (
    <>
      <Restaurant />
    </>
  )
}

export default App